import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { Navigation } from './components/Navigation';
import { TopicCard } from './components/TopicCard';
import { QuizView } from './components/QuizView';
import { LoadingSpinner } from './components/LoadingSpinner';
import { Topic, Problem, UserState } from './types';
import { TOPIC_INFO } from './constants';
import { generateProblemForTopic } from './services/geminiService';
import { Brain, Star, Trophy } from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<'home' | 'quiz' | 'profile'>('home');
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);
  const [currentProblem, setCurrentProblem] = useState<Problem | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [userState, setUserState] = useState<UserState>({
    score: 0,
    completedProblems: 0,
    badges: []
  });

  const handleTopicSelect = async (topic: Topic) => {
    setSelectedTopic(topic);
    setView('quiz');
    await loadProblem(topic);
  };

  const loadProblem = async (topic: Topic) => {
    setIsLoading(true);
    setCurrentProblem(null);
    const problem = await generateProblemForTopic(topic);
    setCurrentProblem(problem);
    setIsLoading(false);
  };

  const handleQuizComplete = (success: boolean) => {
    if (success) {
      setUserState(prev => ({
        ...prev,
        score: prev.score + 10,
        completedProblems: prev.completedProblems + 1
      }));
    }
  };

  const handleNextProblem = () => {
    if (selectedTopic) {
      loadProblem(selectedTopic);
    }
  };

  const renderHome = () => (
    <div className="flex-1 flex flex-col justify-center items-center w-full max-w-2xl mx-auto px-4">
      
      <header className="mb-8 flex flex-col items-center text-center animate-fade-in">
        <div className="flex items-center justify-center gap-3 mb-3">
          <div className="bg-indigo-600 p-3 rounded-2xl shadow-lg text-white transform rotate-3 hover:rotate-0 transition-transform">
            <Brain size={40} />
          </div>
        </div>
        <h1 className="text-4xl font-black tracking-tight mb-1">
          <span className="text-orange-500">RightCode</span> <span className="text-green-700">KidsThink</span>
        </h1>
        <p className="text-indigo-500 text-base font-medium bg-indigo-50 px-3 py-1 rounded-lg">ฝึกทักษะการคิดเชิงคำนวณ</p>
      </header>

      <div className="grid grid-cols-2 gap-4 w-full mb-8">
        {Object.values(Topic).map((topic) => (
          <TopicCard key={topic} topic={topic} onClick={handleTopicSelect} />
        ))}
      </div>
      
      {/* Spacer to push content up slightly from visual center */}
      <div className="h-8"></div>
    </div>
  );

  const renderQuiz = () => {
    if (isLoading || !currentProblem) {
      return (
        <div className="h-screen flex flex-col justify-center items-center bg-indigo-50/50">
           <LoadingSpinner />
        </div>
      );
    }

    return (
      <QuizView 
        problem={currentProblem}
        onComplete={handleQuizComplete}
        onNext={handleNextProblem}
        onBack={() => setView('home')}
      />
    );
  };

  const renderProfile = () => (
    <div className="p-4 pb-24 max-w-2xl mx-auto pt-8 flex flex-col items-center">
      <h2 className="text-3xl font-bold text-indigo-900 mb-8 text-center">ข้อมูลนักคิดของฉัน</h2>
      
      <div className="bg-white rounded-3xl p-8 shadow-lg border-2 border-indigo-50 mb-6 text-center w-full">
        <div className="inline-block p-4 bg-yellow-100 rounded-full mb-4 text-yellow-600 border-4 border-white shadow-sm animate-bounce-slow">
          <Trophy size={56} />
        </div>
        <div className="text-5xl font-black text-gray-800 mb-2">{userState.score}</div>
        <div className="text-gray-500 font-bold uppercase tracking-wider text-sm">คะแนนรวม</div>
      </div>

      <div className="grid grid-cols-2 gap-4 w-full">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
            <div className="text-indigo-500 mb-2"><Star size={32}/></div>
            <div className="text-3xl font-bold text-gray-800">{userState.completedProblems}</div>
            <div className="text-xs text-gray-500 font-medium mt-1">โจทย์ที่ทำสำเร็จ</div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center text-center">
            <div className="text-green-500 mb-2"><Brain size={32}/></div>
            <div className="text-3xl font-bold text-gray-800">1</div>
            <div className="text-xs text-gray-500 font-medium mt-1">ระดับนักคิด</div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f0f9ff] font-sans text-slate-900 flex flex-col">
      
      {view === 'home' && renderHome()}
      {view === 'quiz' && renderQuiz()}
      {view === 'profile' && renderProfile()}

      {/* Developer Footer - Visible only on Home/Profile, positioned at bottom */}
      {view !== 'quiz' && (
         <div className="w-full text-center pb-24 px-4">
            <p className="text-[11px] text-gray-400 font-medium">
              พัฒนาโดย นายธนิท ธนพัตนิรัชกุล ครูผู้ช่วย โรงเรียนกาฬสินธุ์ปัญญานุกูล จังหวัดกาฬสินธุ์
            </p>
         </div>
      )}
      
      <Navigation 
        currentView={view} 
        onNavigate={(v) => setView(v as any)} 
        score={userState.score}
      />
    </div>
  );
};

export default App;