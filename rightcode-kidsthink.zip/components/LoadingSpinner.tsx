import React from 'react';
import { Bot } from 'lucide-react';

export const LoadingSpinner: React.FC = () => (
  <div className="flex flex-col items-center justify-center p-8 space-y-4 animate-bounce-slow">
    <div className="relative">
      <div className="absolute inset-0 bg-indigo-400 rounded-full blur-xl opacity-50 animate-pulse"></div>
      <div className="relative bg-white p-4 rounded-full shadow-lg">
        <Bot size={48} className="text-indigo-600 animate-spin-slow" />
      </div>
    </div>
    <p className="text-indigo-600 font-medium animate-pulse">AI กำลังคิดโจทย์สนุกๆ...</p>
  </div>
);