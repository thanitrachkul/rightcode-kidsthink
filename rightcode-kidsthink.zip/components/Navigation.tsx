import React from 'react';
import { Home, Award, User } from 'lucide-react';

interface NavigationProps {
  onNavigate: (view: string) => void;
  currentView: string;
  score: number;
}

export const Navigation: React.FC<NavigationProps> = ({ onNavigate, currentView, score }) => {
  return (
    <nav className="fixed bottom-0 w-full bg-white border-t border-gray-200 shadow-lg pb-safe z-50">
      <div className="flex justify-around items-center p-3 max-w-2xl mx-auto">
        <button 
          onClick={() => onNavigate('home')}
          className={`flex flex-col items-center p-2 rounded-lg transition-colors ${currentView === 'home' ? 'text-indigo-600' : 'text-gray-500 hover:text-indigo-400'}`}
        >
          <Home size={24} />
          <span className="text-xs font-medium mt-1">หน้าหลัก</span>
        </button>
        
        <div className="flex flex-col items-center bg-indigo-100 px-4 py-2 rounded-full -mt-6 border-4 border-white shadow-md">
          <span className="text-xs font-bold text-indigo-600 uppercase">คะแนน</span>
          <span className="text-xl font-black text-indigo-800">{score}</span>
        </div>

        <button 
           onClick={() => onNavigate('profile')}
           className={`flex flex-col items-center p-2 rounded-lg transition-colors ${currentView === 'profile' ? 'text-indigo-600' : 'text-gray-500 hover:text-indigo-400'}`}
        >
          <User size={24} />
          <span className="text-xs font-medium mt-1">ข้อมูลฉัน</span>
        </button>
      </div>
    </nav>
  );
};