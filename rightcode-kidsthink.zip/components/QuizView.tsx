import React, { useState, useEffect, useRef } from 'react';
import { Problem } from '../types';
import { TOPIC_INFO, BG_MUSIC_URL } from '../constants';
import { getFeedback } from '../services/geminiService';
import { Check, X, HelpCircle, ArrowRight, Volume2, VolumeX } from 'lucide-react';

interface QuizViewProps {
  problem: Problem;
  onComplete: (success: boolean) => void;
  onNext: () => void;
  onBack: () => void;
}

export const QuizView: React.FC<QuizViewProps> = ({ problem, onComplete, onNext, onBack }) => {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [feedback, setFeedback] = useState<string>("");
  const [loadingFeedback, setLoadingFeedback] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const info = TOPIC_INFO[problem.topic];

  // Audio management
  useEffect(() => {
    audioRef.current = new Audio(BG_MUSIC_URL);
    audioRef.current.loop = true;
    audioRef.current.volume = 0.2; // Lower volume for background
    
    const playAudio = async () => {
      try {
        if (audioRef.current && !isMuted) {
          await audioRef.current.play();
        }
      } catch (err) {
        console.log("Autoplay prevented by browser, waiting for interaction");
      }
    };

    playAudio();

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  // Toggle Mute
  useEffect(() => {
    if (audioRef.current) {
      if (isMuted) {
        audioRef.current.pause();
      } else {
        audioRef.current.play().catch(() => {});
      }
    }
  }, [isMuted]);

  const handleOptionClick = (index: number) => {
    if (isSubmitted) return;
    setSelectedOption(index);
  };

  const handleSubmit = async () => {
    if (selectedOption === null) return;
    
    setIsSubmitted(true);
    setLoadingFeedback(true);
    
    const isCorrect = selectedOption === problem.correctOptionIndex;
    const feedbackText = await getFeedback(
      isCorrect, 
      problem.options[selectedOption].text, 
      problem
    );
    
    setFeedback(feedbackText);
    setLoadingFeedback(false);
    onComplete(isCorrect);
  };

  useEffect(() => {
    setSelectedOption(null);
    setIsSubmitted(false);
    setFeedback("");
    setShowHint(false);
  }, [problem.id]);

  return (
    <div className="min-h-screen flex flex-col pb-24 bg-[#f0f9ff]">
      {/* Navbar */}
      <div className="bg-white px-4 py-3 flex items-center justify-between shadow-sm z-10">
        <button onClick={onBack} className="p-2 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors">
          <ArrowRight className="transform rotate-180" size={24} />
        </button>
        <span className={`px-4 py-1.5 rounded-full text-sm font-bold ${info.lightColor} ${info.textColor}`}>
          {info.thaiTitle}
        </span>
        <button onClick={() => setIsMuted(!isMuted)} className="p-2 text-gray-400 hover:text-indigo-500">
           {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
        </button>
      </div>

      <div className="flex-1 p-4 max-w-md mx-auto w-full flex flex-col gap-4">
        
        {/* Visual Stage & Question */}
        <div className="bg-white rounded-3xl p-6 shadow-md border-2 border-indigo-50 text-center relative overflow-hidden">
           {/* Decorative blobs */}
           <div className="absolute top-0 left-0 w-16 h-16 bg-yellow-100 rounded-br-full opacity-50"></div>
           <div className="absolute bottom-0 right-0 w-16 h-16 bg-indigo-100 rounded-tl-full opacity-50"></div>

          <div className="text-6xl mb-2 animate-bounce-slow select-none">
            {problem.sceneEmojis}
          </div>
          
          {/* Question is now HUGE and Dominant */}
          <h2 className="text-3xl font-black text-indigo-900 leading-tight mb-3 mt-2 drop-shadow-sm">
            {problem.question}
          </h2>

          {/* Context is smaller */}
          <div className="inline-block px-3 py-1 bg-gray-100 rounded-lg text-gray-500 text-sm font-medium">
            สถานการณ์: {problem.storyContext}
          </div>
        </div>

        {/* Options Grid */}
        <div className="grid grid-cols-2 gap-3 flex-1 min-h-[200px]">
          {problem.options.map((option, idx) => {
            const isSelected = selectedOption === idx;
            const isCorrect = idx === problem.correctOptionIndex;
            
            let cardClass = "relative flex flex-col items-center justify-center p-3 rounded-2xl border-b-4 transition-all duration-200 active:scale-95 ";
            
            if (isSubmitted) {
              if (isCorrect) {
                cardClass += "bg-green-100 border-green-400 text-green-800";
              } else if (isSelected) {
                cardClass += "bg-red-100 border-red-400 text-red-800 opacity-80";
              } else {
                cardClass += "bg-gray-50 border-gray-200 opacity-40 grayscale";
              }
            } else {
              if (isSelected) {
                cardClass += "bg-indigo-100 border-indigo-400 ring-2 ring-indigo-400 ring-offset-2";
              } else {
                cardClass += "bg-white border-gray-200 hover:bg-gray-50 hover:border-gray-300 shadow-sm";
              }
            }

            return (
              <button 
                key={idx} 
                onClick={() => handleOptionClick(idx)}
                disabled={isSubmitted}
                className={cardClass}
              >
                <div className="text-5xl mb-2 drop-shadow-sm">{option.emoji}</div>
                <span className="font-bold text-lg leading-none text-center">{option.text}</span>
                
                {isSubmitted && isCorrect && (
                  <div className="absolute top-2 right-2 bg-green-500 text-white rounded-full p-1 shadow-md animate-bounce">
                    <Check size={16} strokeWidth={4} />
                  </div>
                )}
                 {isSubmitted && isSelected && !isCorrect && (
                  <div className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 shadow-md">
                    <X size={16} strokeWidth={4} />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Controls */}
        <div className="space-y-3">
          {!isSubmitted ? (
             <div className="flex gap-3">
               <button 
                 onClick={() => setShowHint(!showHint)}
                 className="p-4 rounded-2xl bg-yellow-100 text-yellow-700 border-b-4 border-yellow-300 active:border-b-0 active:translate-y-1 transition-all shadow-sm"
               >
                 <HelpCircle size={28} />
               </button>
               <button 
                 onClick={handleSubmit}
                 disabled={selectedOption === null}
                 className={`flex-1 rounded-2xl font-black text-2xl text-white shadow-lg border-b-4 active:border-b-0 active:translate-y-1 transition-all py-3
                   ${selectedOption === null 
                     ? 'bg-gray-300 border-gray-400 cursor-not-allowed' 
                     : 'bg-gradient-to-r from-indigo-500 to-purple-600 border-indigo-700 hover:from-indigo-600 hover:to-purple-700'
                   }`}
               >
                 ตอบเลย!
               </button>
             </div>
          ) : (
            <div className="animate-fade-in space-y-3">
              <div className={`p-4 rounded-2xl border-2 text-center ${selectedOption === problem.correctOptionIndex ? 'bg-green-50 border-green-200' : 'bg-orange-50 border-orange-200'}`}>
                 <p className="text-xl font-black mb-1">
                   {loadingFeedback ? "..." : feedback}
                 </p>
                 {!loadingFeedback && (
                   <p className="text-sm text-gray-600 opacity-80">{problem.explanation}</p>
                 )}
              </div>
              <button 
                onClick={onNext}
                className="w-full py-4 bg-indigo-500 text-white rounded-2xl font-black text-xl shadow-xl border-b-4 border-indigo-700 active:border-b-0 active:translate-y-1 transition-all flex items-center justify-center gap-2"
              >
                <span>ข้อต่อไป</span>
                <ArrowRight size={24} strokeWidth={3} />
              </button>
            </div>
          )}

          {showHint && !isSubmitted && (
            <div className="bg-yellow-50 p-4 rounded-2xl border border-yellow-200 text-yellow-800 text-center animate-bounce-slow shadow-sm">
               <span className="font-bold mr-2">คำใบ้:</span> {problem.hint}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};