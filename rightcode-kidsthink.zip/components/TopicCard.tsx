import React from 'react';
import { Topic } from '../types';
import { TOPIC_INFO } from '../constants';
import { LucideIcon } from 'lucide-react';

interface TopicCardProps {
  topic: Topic;
  onClick: (topic: Topic) => void;
}

export const TopicCard: React.FC<TopicCardProps> = ({ topic, onClick }) => {
  const info = TOPIC_INFO[topic];
  const Icon: LucideIcon = info.icon;

  return (
    <button
      onClick={() => onClick(topic)}
      className={`${info.color} ${info.hoverColor} group relative w-full overflow-hidden rounded-3xl p-4 h-40 flex flex-col justify-between text-left transition-all hover:scale-[1.02] active:scale-95 shadow-md border-b-4 border-black/10`}
    >
      {/* Background Decor Icon */}
      <div className="absolute right-[-10px] bottom-[-10px] opacity-20 rotate-12 transition-transform group-hover:scale-110 group-hover:rotate-6">
        <Icon size={80} className="text-white" />
      </div>
      
      <div className="relative z-10">
        <div className="bg-white/20 p-2 rounded-xl w-fit mb-2 backdrop-blur-sm">
          <Icon size={24} className="text-white" strokeWidth={2.5} />
        </div>
        <h3 className="text-lg font-black font-prompt tracking-wide leading-tight text-white mb-1">
          {info.thaiTitle}
        </h3>
      </div>
      
      <div className="relative z-10">
         <p className="text-white/90 text-[10px] font-medium bg-black/10 px-2 py-1 rounded-lg inline-block backdrop-blur-sm line-clamp-1">
          {info.description}
        </p>
      </div>
    </button>
  );
};