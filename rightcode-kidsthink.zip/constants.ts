import { Topic, Problem } from './types';
import { LayoutGrid, Search, Eye, ListOrdered } from 'lucide-react';

// Changed to "Cute Creatures" - a funny, pizzicato, thinking-style track
export const BG_MUSIC_URL = "https://cdn.pixabay.com/download/audio/2023/08/02/audio_320276c250.mp3?filename=cute-creatures-161885.mp3?v=2";

export const TOPIC_INFO = {
  [Topic.DECOMPOSITION]: {
    title: "แตกปัญหาใหญ่",
    thaiTitle: "การแยกย่อยปัญหา",
    description: "แบ่งงานใหญ่เป็นงานย่อยๆ",
    color: "bg-rose-400",
    hoverColor: "hover:bg-rose-500",
    lightColor: "bg-rose-100",
    borderColor: "border-rose-200",
    textColor: "text-rose-600",
    icon: LayoutGrid
  },
  [Topic.PATTERN_RECOGNITION]: {
    title: "หารูปแบบ",
    thaiTitle: "การหารูปแบบ",
    description: "หาความเหมือนที่ซ่อนอยู่",
    color: "bg-amber-400",
    hoverColor: "hover:bg-amber-500",
    lightColor: "bg-amber-100",
    borderColor: "border-amber-200",
    textColor: "text-amber-600",
    icon: Search
  },
  [Topic.ABSTRACTION]: {
    title: "จับจุดสำคัญ",
    thaiTitle: "การคิดเชิงนามธรรม",
    description: "โฟกัสแค่สิ่งที่สำคัญ",
    color: "bg-sky-400",
    hoverColor: "hover:bg-sky-500",
    lightColor: "bg-sky-100",
    borderColor: "border-sky-200",
    textColor: "text-sky-600",
    icon: Eye
  },
  [Topic.ALGORITHM]: {
    title: "ลำดับขั้นตอน",
    thaiTitle: "การออกแบบขั้นตอนวิธี",
    description: "วางแผนการทำงานเป็นลำดับ",
    color: "bg-emerald-400",
    hoverColor: "hover:bg-emerald-500",
    lightColor: "bg-emerald-100",
    borderColor: "border-emerald-200",
    textColor: "text-emerald-600",
    icon: ListOrdered
  }
};

export const FALLBACK_PROBLEM: Problem = {
  id: 'fallback-1',
  topic: Topic.ALGORITHM,
  sceneEmojis: "🐱 🏠 🚧",
  storyContext: "แมวเหมียวหลงทาง ช่วยพาเดินกลับบ้านหน่อย",
  question: "ทางไหนถึงบ้านเร็วสุด?",
  options: [
    { text: "เดินตรง -> เลี้ยวซ้าย", emoji: "⬅️" },
    { text: "นอนหลับ", emoji: "💤" },
    { text: "เดินถอยหลัง", emoji: "🔙" },
    { text: "วิ่งวนรอบตัว", emoji: "🔄" }
  ],
  correctOptionIndex: 0,
  hint: "ดูที่ลูกศรนะ แมวต้องเดินไปข้างหน้า",
  explanation: "ต้องเดินไปข้างหน้าแล้วเลี้ยวซ้ายถึงจะเจอประตูบ้าน"
};