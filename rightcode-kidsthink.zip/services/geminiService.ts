import { GoogleGenAI, Type } from "@google/genai";
import { Topic, Problem } from "../types";
import { FALLBACK_PROBLEM } from "../constants";

const apiKey = process.env.API_KEY;

// Safely initialize Gemini
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
} else {
  console.warn("API_KEY is missing. App will run in fallback mode.");
}

export const generateProblemForTopic = async (topic: Topic): Promise<Problem> => {
  if (!ai) return FALLBACK_PROBLEM;

  const prompt = `
    You are creating a Visual Computational Thinking puzzle for a young child (Grade 2-3).
    Topic: ${topic}.
    Language: Thai.
    
    RULES:
    1. USE VERY FEW WORDS. Focus on Visuals/Symbols.
    2. The "storyContext" must be 1 short sentence (Max 15 words).
    3. Provide "sceneEmojis" (3-5 emojis) that visualize the story.
    4. Options must have an Emoji and very short text (1-3 words).
    5. Make it fun and cute.

    Output strictly in JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sceneEmojis: { type: Type.STRING, description: "3-5 emojis illustrating the story" },
            storyContext: { type: Type.STRING, description: "Very short story (Thai, max 15 words)" },
            question: { type: Type.STRING, description: "Simple question (Thai)" },
            options: { 
              type: Type.ARRAY, 
              items: { 
                type: Type.OBJECT,
                properties: {
                  text: { type: Type.STRING, description: "Short answer text (1-3 words)" },
                  emoji: { type: Type.STRING, description: "Single emoji representing this answer" }
                },
                required: ["text", "emoji"]
              }, 
              description: "4 options" 
            },
            correctOptionIndex: { type: Type.INTEGER, description: "Index of correct answer (0-3)" },
            hint: { type: Type.STRING, description: "Short hint (Thai)" },
            explanation: { type: Type.STRING, description: "Simple explanation (Thai)" }
          },
          required: ["sceneEmojis", "storyContext", "question", "options", "correctOptionIndex", "hint", "explanation"]
        }
      }
    });

    if (response.text) {
      const data = JSON.parse(response.text);
      return {
        id: Date.now().toString(),
        topic,
        ...data
      };
    }
    return FALLBACK_PROBLEM;
  } catch (error) {
    console.error("Gemini Generation Error:", error);
    return FALLBACK_PROBLEM;
  }
};

export const getFeedback = async (isCorrect: boolean, userChoiceText: string, problem: Problem): Promise<string> => {
  if (!ai) return isCorrect ? "เก่งมาก!" : "ลองใหม่นะ";

  const prompt = `
    Student answered a kids quiz.
    Question: ${problem.question}
    Answered: ${userChoiceText}
    Correct: ${isCorrect}
    
    Reply in Thai. Max 10 words. Fun and encouraging.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || (isCorrect ? "สุดยอดไปเลย!" : "สู้ๆ ลองใหม่นะ");
  } catch (e) {
    return isCorrect ? "เย้ ถูกต้อง!" : "ยังไม่ถูกนะ";
  }
};