export enum Topic {
  DECOMPOSITION = 'Decomposition',
  PATTERN_RECOGNITION = 'Pattern Recognition',
  ABSTRACTION = 'Abstraction',
  ALGORITHM = 'Algorithm Design'
}

export interface QuizOption {
  text: string;
  emoji: string;
}

export interface Problem {
  id: string;
  topic: Topic;
  sceneEmojis: string; // A string of emojis representing the scene
  storyContext: string; // Very short text
  question: string;
  options: QuizOption[];
  correctOptionIndex: number;
  hint: string;
  explanation: string;
}

export interface UserState {
  score: number;
  completedProblems: number;
  badges: string[];
}

export interface Message {
  role: 'user' | 'model';
  text: string;
}